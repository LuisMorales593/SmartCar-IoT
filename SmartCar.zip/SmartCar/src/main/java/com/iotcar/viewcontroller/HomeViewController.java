package com.iotcar.viewcontroller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeViewController {

    @GetMapping("/")
    public String home(HttpSession session) {
        // Si no está logueado, va al login
        if (session.getAttribute("usuarioId") == null) {
            return "redirect:/login";
        }
        // Si ya está logueado, va según su rol
        String rol = (String) session.getAttribute("rol");
        if ("admin".equals(rol)) {
            return "redirect:/web/vehiculos";
        }
        return "redirect:/web/control";
    }
}