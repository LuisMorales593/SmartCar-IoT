package com.iotcar.viewcontroller;

import com.iotcar.entity.Usuario;
import com.iotcar.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
public class UsuarioViewController {

    @Autowired
    private UsuarioRepository repository;

    @GetMapping("/web/usuarios")
    public String listar(Model model) {
        model.addAttribute("usuarios", repository.findAll());
        model.addAttribute("usuario", new Usuario());
        model.addAttribute("contenido", "usuarios");
        return "layout";
    }

    @PostMapping("/web/usuarios/guardar")
    public String guardar(@ModelAttribute Usuario usuario, RedirectAttributes redirectAttrs) {
        // ✅ Verificar email duplicado
        Optional<Usuario> existente = repository.findByEmail(usuario.getEmail());
        if (existente.isPresent()) {
            // Si es edición y el email pertenece al mismo usuario → OK
            // Si es nuevo o el email pertenece a otro usuario → error
            boolean esMismoUsuario = usuario.getId() != null 
                    && existente.get().getId().equals(usuario.getId());
            
            if (!esMismoUsuario) {
                redirectAttrs.addFlashAttribute("error", 
                    "Ya existe un usuario con el email: " + usuario.getEmail());
                return "redirect:/web/usuarios";
            }
        }

        repository.save(usuario);
        redirectAttrs.addFlashAttribute("exito", 
            usuario.getId() == null ? "Usuario creado correctamente" : "Usuario actualizado correctamente");
        return "redirect:/web/usuarios";
    }

    @GetMapping("/web/usuarios/editar/{id}")
    public String editar(@PathVariable Long id, Model model, RedirectAttributes redirectAttrs) {
        Usuario usuario = repository.findById(id).orElse(null);
        if (usuario == null) {
            redirectAttrs.addFlashAttribute("error", "Usuario no encontrado");
            return "redirect:/web/usuarios";
        }
        model.addAttribute("usuario", usuario);
        model.addAttribute("usuarios", repository.findAll());
        model.addAttribute("contenido", "usuarios");
        return "layout";
    }

    @GetMapping("/web/usuarios/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes redirectAttrs) {
        try {
            repository.deleteById(id);
            redirectAttrs.addFlashAttribute("exito", "Usuario eliminado correctamente");
        } catch (Exception e) {
            redirectAttrs.addFlashAttribute("error", 
                "No se pudo eliminar el usuario (puede tener sesiones asociadas)");
        }
        return "redirect:/web/usuarios";
    }
}