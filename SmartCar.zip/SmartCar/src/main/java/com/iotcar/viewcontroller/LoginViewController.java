package com.iotcar.viewcontroller;

import com.iotcar.entity.Usuario;
import com.iotcar.repository.UsuarioRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginViewController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @GetMapping("/login")
    public String login(HttpSession session) {
        // Si ya está logueado, redirigir según rol
        if (session.getAttribute("usuarioId") != null) {
            return redirigirPorRol((String) session.getAttribute("rol"));
        }
        return "login";
    }

    @PostMapping("/login")
    public String procesarLogin(@RequestParam String email,
                                @RequestParam String password,
                                HttpSession session,
                                Model model) {
        Usuario usuario = usuarioRepository.findByEmail(email).orElse(null);

        // 1. Validar credenciales
        if (usuario == null || !password.equals(usuario.getPassword())) {
            model.addAttribute("error", "Credenciales inválidas");
            model.addAttribute("emailPrevio", email);
            return "login";
        }

        // 2. Validar que esté activo
        if (usuario.getActivo() == null || !usuario.getActivo()) {
            model.addAttribute("error", "Usuario desactivado. Contacta al administrador.");
            model.addAttribute("emailPrevio", email);
            return "login";
        }

        // 3. Guardar en sesión HTTP
        session.setAttribute("usuarioId", usuario.getId());
        session.setAttribute("nombre", usuario.getNombre());
        session.setAttribute("email", usuario.getEmail());
        session.setAttribute("rol", usuario.getRol());

        // 4. Redirigir según rol
        return redirigirPorRol(usuario.getRol());
    }

    private String redirigirPorRol(String rol) {
        if ("admin".equals(rol)) {
            return "redirect:/web/vehiculos";
        }
        return "redirect:/web/control";
    }
}