package com.iotcar.viewcontroller;

import com.iotcar.entity.Comando;
import com.iotcar.entity.Sesion;
import com.iotcar.entity.Vehiculo;
import com.iotcar.repository.ComandoRepository;
import com.iotcar.repository.SesionRepository;
import com.iotcar.repository.VehiculoRepository;
import com.iotcar.config.ComandoWebSocketHandler;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.time.LocalDateTime;
import java.util.List;

@Controller
public class ControlViewController {

    private static final String VELOCIDAD_SESSION_KEY = "velocidadActual";
    private static final String MOTOR_SESSION_KEY = "motorEncendido";
    private static final String SISTEMA_SESSION_KEY = "sistemaEncendido";

    @Autowired
    private ComandoRepository comandoRepository;

    @Autowired
    private VehiculoRepository vehiculoRepository;

    @Autowired
    private SesionRepository sesionRepository;

    @GetMapping("/web/control")
    public String control(@RequestParam(required = false) Long vehiculoId,
                          HttpSession session,
                          Model model) {
        if (vehiculoId == null) {
            vehiculoId = (Long) session.getAttribute("vehiculoId");
        }

        model.addAttribute("contenido", "control");
        model.addAttribute("vehiculoId", vehiculoId);

        Integer velocidadActual = (Integer) session.getAttribute(VELOCIDAD_SESSION_KEY);
        if (velocidadActual == null) velocidadActual = 0;
        model.addAttribute("velocidadActual", velocidadActual);

        Boolean motorEncendido = (Boolean) session.getAttribute(MOTOR_SESSION_KEY);
        if (motorEncendido == null) motorEncendido = false;
        model.addAttribute("motorEncendido", motorEncendido);

        Boolean sistemaEncendido = (Boolean) session.getAttribute(SISTEMA_SESSION_KEY);
        if (sistemaEncendido == null) sistemaEncendido = false;
        model.addAttribute("sistemaEncendido", sistemaEncendido);

        // ===== ESTADOS DE LAS LUCES (para que persistan al recargar) =====
        model.addAttribute("lucesAltas", Boolean.TRUE.equals(session.getAttribute("luz_luces_altas")));
        model.addAttribute("lucesBajas", Boolean.TRUE.equals(session.getAttribute("luz_luces_bajas")));
        model.addAttribute("lucesTecho", Boolean.TRUE.equals(session.getAttribute("luz_luces_techo")));
        model.addAttribute("lucesTablero", Boolean.TRUE.equals(session.getAttribute("luz_luces_tablero")));
        model.addAttribute("lucesMotor", Boolean.TRUE.equals(session.getAttribute("luz_luces_motor")));
        // ==================================================================

        if (vehiculoId != null) {
            Vehiculo vehiculo = vehiculoRepository.findById(vehiculoId).orElse(null);
            if (vehiculo != null) {
                model.addAttribute("vehiculoConectado", "CONECTADO".equals(vehiculo.getEstado()));
                model.addAttribute("ipVehiculo", vehiculo.getIp()); 
                
                Float voltaje = vehiculo.getBateria();
                int porcentaje = 0;
                
                if (voltaje != null) {
                    if (voltaje >= 8.4) {
                        porcentaje = 100;
                    } else if (voltaje <= 7.0) {
                        porcentaje = 0;
                    } else {
                        porcentaje = (int) (((voltaje - 7.0) / 1.4) * 100);
                    }
                }
                
                model.addAttribute("bateriaPorcentaje", porcentaje);
                model.addAttribute("bateriaVoltaje", voltaje != null ? String.format("%.2f", voltaje) : "0.00");

                List<Sesion> sesiones = sesionRepository.findByVehiculoIdAndActivaTrue(vehiculoId);
                if (!sesiones.isEmpty()) {
                    model.addAttribute("sesionId", sesiones.get(0).getId());
                }
            } else {
                model.addAttribute("vehiculoConectado", false);
            }
        } else {
            model.addAttribute("vehiculoConectado", false);
        }

        return "layout";
    }

    @PostMapping("/web/control/comando")
    @ResponseBody 
    public String recibirComando(@RequestParam String comando,
                                 @RequestParam Long vehiculoId,
                                 @RequestParam(required = false) String valor,
                                 HttpSession session) {

        Long usuarioId = (Long) session.getAttribute("usuarioId");
        if (usuarioId == null) usuarioId = 1L;

        String mensajeWS;
        String tipoBD = null;
        String valorBD = null;
        boolean guardarEnBD = true;

        // ===== SISTEMA =====
        if ("arrancar".equals(comando)) {
            boolean encendido = "on".equals(valor);
            session.setAttribute(SISTEMA_SESSION_KEY, encendido);
            if (!encendido) {
                session.setAttribute(VELOCIDAD_SESSION_KEY, 0);
                session.setAttribute(MOTOR_SESSION_KEY, false);
                session.setAttribute("luz_luces_altas", false);
                session.setAttribute("luz_luces_bajas", false);
                session.setAttribute("luz_luces_motor", false);
                session.setAttribute("luz_luces_techo", false);
                session.setAttribute("luz_luces_tablero", false);
            }
            mensajeWS = "{\"tipo\":\"arrancar\",\"valor\":\"" + (encendido ? "on" : "off") + "\"}";
            tipoBD = "arrancar";
            valorBD = encendido ? "on" : "off";
        }
        // ===== MOTOR (actúa como puerta de las luces) =====
        else if ("motor".equals(comando)) {
            boolean encendido = "on".equals(valor);
            session.setAttribute(MOTOR_SESSION_KEY, encendido);
            
            if (encendido) {
                // Motor ON → luces motor se prenden automáticas en el ESP32
                session.setAttribute("luz_luces_motor", true);
            } else {
                // Motor OFF → apagar TODAS las luces que estuvieran encendidas
                session.setAttribute(VELOCIDAD_SESSION_KEY, 0);
                
                boolean[] apagar = {
                    Boolean.TRUE.equals(session.getAttribute("luz_luces_altas")),
                    Boolean.TRUE.equals(session.getAttribute("luz_luces_bajas")),
                    Boolean.TRUE.equals(session.getAttribute("luz_luces_techo")),
                    Boolean.TRUE.equals(session.getAttribute("luz_luces_tablero"))
                };
                String[] tipos = {"luces_altas","luces_bajas","luces_techo","luces_tablero"};
                
                // Reset sesión
                session.setAttribute("luz_luces_altas", false);
                session.setAttribute("luz_luces_bajas", false);
                session.setAttribute("luz_luces_techo", false);
                session.setAttribute("luz_luces_tablero", false);
                session.setAttribute("luz_luces_motor", false);
                
                // Enviar off al ESP32 para las que estaban prendidas
                for (int i = 0; i < tipos.length; i++) {
                    if (apagar[i]) {
                        ComandoWebSocketHandler.enviarComando(vehiculoId,
                            "{\"tipo\":\"" + tipos[i] + "\",\"valor\":\"off\"}");
                    }
                }
            }
            
            mensajeWS = "{\"tipo\":\"motor\",\"valor\":\"" + (encendido ? "on" : "off") + "\"}";
            tipoBD = "motor";
            valorBD = encendido ? "on" : "off";
        }
        // ===== CÁMARA ON/OFF =====
        else if ("camara_on".equals(comando) || "camara_off".equals(comando)) {
            mensajeWS = "{\"tipo\":\"" + comando + "\",\"valor\":\"\"}";
            ComandoWebSocketHandler.enviarComando(vehiculoId, mensajeWS);
            return "ok";
        }
        // ===== SUBIENDO / BAJANDO / VELOCIDADES =====
        else if ("subiendo".equals(comando) || "bajando".equals(comando) ||
                 "velocidad_uno_mas".equals(comando) || "velocidad_uno_menos".equals(comando) ||
                 "freno".equals(comando) || "stop_freno".equals(comando)) {
            
            if ("velocidad_uno_mas".equals(comando)) {
                Integer vActual = (Integer) session.getAttribute(VELOCIDAD_SESSION_KEY);
                if (vActual == null) vActual = 0;
                int vNuevo = Math.min(vActual + 5, 100);
                session.setAttribute(VELOCIDAD_SESSION_KEY, vNuevo);
                mensajeWS = "{\"tipo\":\"velocidad\",\"valor\":\"" + vNuevo + "\"}";
            } else if ("velocidad_uno_menos".equals(comando)) {
                Integer vActual = (Integer) session.getAttribute(VELOCIDAD_SESSION_KEY);
                if (vActual == null) vActual = 0;
                int vNuevo = Math.max(vActual - 5, -100);
                session.setAttribute(VELOCIDAD_SESSION_KEY, vNuevo);
                mensajeWS = "{\"tipo\":\"velocidad\",\"valor\":\"" + vNuevo + "\"}";
            } else {
                mensajeWS = "{\"tipo\":\"" + comando + "\",\"valor\":\"" + (valor != null ? valor : "") + "\"}";
            }
            ComandoWebSocketHandler.enviarComando(vehiculoId, mensajeWS);
            return "ok";
        }
        // ===== VELOCIDAD GUARDADA (SIN SATURAR BD) =====
        else if ("velocidad".equals(comando)) {
            int v = Integer.parseInt(valor);
            v = Math.max(-100, Math.min(100, v));
            session.setAttribute(VELOCIDAD_SESSION_KEY, v);
            mensajeWS = "{\"tipo\":\"velocidad\",\"valor\":\"" + v + "\"}";
            guardarEnBD = false;
        }
        // ===== DIRECCIÓN =====
        else if ("izquierda".equals(comando) || "derecha".equals(comando) || "stop".equals(comando)) {
            mensajeWS = "{\"tipo\":\"direccion\",\"valor\":\"" + comando + "\"}";
            tipoBD = "direccion";
            valorBD = comando;
        }
        // ===== LUCES =====
        else if (comando.startsWith("luces_")) {
            String key = "luz_" + comando;
            Boolean estadoActual = (Boolean) session.getAttribute(key);
            if (estadoActual == null) estadoActual = false;
            boolean nuevoEstado = !estadoActual;
            session.setAttribute(key, nuevoEstado);
            String valorLuz = nuevoEstado ? "on" : "off";
            mensajeWS = "{\"tipo\":\"" + comando + "\",\"valor\":\"" + valorLuz + "\"}";
            tipoBD = comando;
            valorBD = valorLuz;
        }
        // ===== RESET =====
        else if ("reset".equals(comando)) {
            session.setAttribute(VELOCIDAD_SESSION_KEY, 0);
            session.setAttribute(MOTOR_SESSION_KEY, false);
            session.setAttribute(SISTEMA_SESSION_KEY, false);
            session.setAttribute("luz_luces_altas", false);
            session.setAttribute("luz_luces_bajas", false);
            session.setAttribute("luz_luces_motor", false);
            session.setAttribute("luz_luces_techo", false);
            session.setAttribute("luz_luces_tablero", false);
            mensajeWS = "{\"tipo\":\"reset\",\"valor\":\"\"}";
            tipoBD = "reset";
            valorBD = "";
        }
        // ===== POR DEFECTO =====
        else {
            mensajeWS = "{\"tipo\":\"direccion\",\"valor\":\"" + comando + "\"}";
            tipoBD = "direccion";
            valorBD = comando;
        }

        ComandoWebSocketHandler.enviarComando(vehiculoId, mensajeWS);

        if (guardarEnBD && tipoBD != null) {
            Comando cmd = new Comando();
            cmd.setVehiculoId(vehiculoId);
            cmd.setUsuarioId(usuarioId);
            cmd.setFecha(LocalDateTime.now());
            cmd.setTipo(tipoBD);
            cmd.setValor(valorBD != null ? valorBD : "");
            comandoRepository.save(cmd);
        }
        return "ok"; 
    }
}