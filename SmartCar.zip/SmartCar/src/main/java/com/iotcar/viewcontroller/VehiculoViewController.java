package com.iotcar.viewcontroller;

import com.iotcar.entity.Vehiculo;
import com.iotcar.repository.VehiculoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Controller
public class VehiculoViewController {

    @Autowired
    private VehiculoRepository repository;

    @GetMapping("/web/vehiculos")
    public String listar(Model model) {
        model.addAttribute("vehiculos", repository.findAll());
        model.addAttribute("vehiculo", new Vehiculo());
        model.addAttribute("contenido", "vehiculos");
        return "layout";
    }

    @PostMapping("/web/vehiculos/guardar")
    public String guardar(@ModelAttribute Vehiculo vehiculo, RedirectAttributes redirectAttrs) {
        // ✅ Verificar nombre duplicado
        List<Vehiculo> todos = repository.findAll();
        for (Vehiculo v : todos) {
            if (v.getNombre() != null 
                    && v.getNombre().equalsIgnoreCase(vehiculo.getNombre().trim())
                    && (vehiculo.getId() == null || !v.getId().equals(vehiculo.getId()))) {
                redirectAttrs.addFlashAttribute("error", 
                    "Ya existe un vehículo con el nombre: " + vehiculo.getNombre());
                return "redirect:/web/vehiculos";
            }
        }

        // Normalizar nombre
        vehiculo.setNombre(vehiculo.getNombre().trim());

        if (vehiculo.getId() == null) {
            // Crear nuevo → estado por defecto DESCONECTADO
            if (vehiculo.getEstado() == null) {
                vehiculo.setEstado("DESCONECTADO");
            }
            if (vehiculo.getUltimaConexion() == null) {
                vehiculo.setUltimaConexion(LocalDateTime.now());
            }
            repository.save(vehiculo);
            redirectAttrs.addFlashAttribute("exito", "Vehículo creado correctamente");
        } else {
            // Editar → preservar campos del sistema (batería, estado, última conexión)
            Optional<Vehiculo> existenteOpt = repository.findById(vehiculo.getId());
            if (existenteOpt.isEmpty()) {
                redirectAttrs.addFlashAttribute("error", "Vehículo no encontrado");
                return "redirect:/web/vehiculos";
            }
            Vehiculo existente = existenteOpt.get();
            existente.setNombre(vehiculo.getNombre());
            existente.setModelo(vehiculo.getModelo());
            existente.setControlador(vehiculo.getControlador());
            existente.setIp(vehiculo.getIp());
            existente.setUrlStream(vehiculo.getUrlStream());
            // No tocamos: estado, estadoBateria, bateria, ultimaConexion
            repository.save(existente);
            redirectAttrs.addFlashAttribute("exito", "Vehículo actualizado correctamente");
        }

        return "redirect:/web/vehiculos";
    }

    @GetMapping("/web/vehiculos/editar/{id}")
    public String editar(@PathVariable Long id, Model model, RedirectAttributes redirectAttrs) {
        Vehiculo vehiculo = repository.findById(id).orElse(null);
        if (vehiculo == null) {
            redirectAttrs.addFlashAttribute("error", "Vehículo no encontrado");
            return "redirect:/web/vehiculos";
        }
        model.addAttribute("vehiculo", vehiculo);
        model.addAttribute("vehiculos", repository.findAll());
        model.addAttribute("contenido", "vehiculos");
        return "layout";
    }

    @GetMapping("/web/vehiculos/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes redirectAttrs) {
        try {
            repository.deleteById(id);
            redirectAttrs.addFlashAttribute("exito", "Vehículo eliminado correctamente");
        } catch (Exception e) {
            redirectAttrs.addFlashAttribute("error", 
                "No se pudo eliminar el vehículo (puede tener sesiones o comandos asociados)");
        }
        return "redirect:/web/vehiculos";
    }
}