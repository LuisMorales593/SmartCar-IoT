package com.iotcar.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class AuthInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response,
                             Object handler) throws Exception {

        String uri = request.getRequestURI();

        // ===== RUTAS PÚBLICAS (no requieren sesión) =====
        // Login, logout, recursos estáticos, WebSocket del ESP32, API REST del ESP32
        if (uri.equals("/login") ||
            uri.equals("/logout") ||
            uri.startsWith("/css/") ||
            uri.startsWith("/js/") ||
            uri.startsWith("/img/") ||
            uri.startsWith("/ws/") ||
            uri.startsWith("/vehiculos") ||
            uri.startsWith("/comandos") ||
            uri.startsWith("/telemetria") ||
            uri.startsWith("/usuarios")) {
            return true;  // deja pasar sin chequear
        }

        // ===== A PARTIR DE AQUÍ, REQUIERE SESIÓN =====
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioId") == null) {
            // No hay sesión → al login
            response.sendRedirect("/login");
            return false;
        }

        // ===== RUTAS SOLO ADMIN =====
        if (uri.startsWith("/web/usuarios") || uri.startsWith("/web/vehiculos")) {
            String rol = (String) session.getAttribute("rol");
            if (!"admin".equals(rol)) {
                // No es admin → lo mandamos al control
                response.sendRedirect("/web/control");
                return false;
            }
        }

        // ===== TODO OK =====
        return true;
    }
}